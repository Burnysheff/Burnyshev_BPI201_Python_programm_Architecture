class Matrix:
    def Enter(self, arraySymbols, position):
        pass

    def EnterRandom(self):
        pass

    def Print(self, outfile):
        pass

    def Average(self):
        pass